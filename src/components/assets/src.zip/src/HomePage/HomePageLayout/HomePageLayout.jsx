
import React from 'react'
import { Container, Row, Col } from "react-bootstrap"; // Bootstrap components
import "bootstrap/dist/css/bootstrap.min.css"; // Bootstrap styles
import { Avatar, Box, Button, Card, TextField } from "@mui/material";
import VideoCallIcon from "@mui/icons-material/VideoCall";
import PhotoCameraIcon from "@mui/icons-material/PhotoCamera";
import ArticleIcon from "@mui/icons-material/Article";
import AboutSection from './AboutSection';
import GamesSection from './GamesSection';
import PostSection from './PostSection';

const HomePageLayout = () => {
    return (
        <Container className=" mt-4">

            <Row className="gy-4">

                {/* AboutSection */}

                <Col lg={3} className="d-none d-lg-block">

                    <AboutSection />

                </Col>


                {/* Post Section */}

                <Col lg={6}>

                    <PostSection />

                </Col>

                {/* Games Section */}

                <Col lg={3} className="d-none d-lg-block">

                    <GamesSection />

                </Col>

            </Row>

        </Container>
        
    )
}

export default HomePageLayout