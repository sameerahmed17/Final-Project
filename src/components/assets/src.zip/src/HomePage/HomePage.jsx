import React from "react";
import "../App.css";
import { Container, Row, Col } from "react-bootstrap"; // Bootstrap components
import "bootstrap/dist/css/bootstrap.min.css"; // Bootstrap styles
import { Box, } from "@mui/material";

import Header from "../AllPages/Header";
import HomePageLayout from "./HomePageLayout/HomePageLayout";

const HomePage = () => {
    return (
        <Box style={{ backgroundColor: '#f4f2ee' }}>
            <Box className=' sticky-top'>
                <Header />
            </Box>

            <HomePageLayout />
            
        </Box>
    )
}

export default HomePage