import React from 'react'
import "bootstrap/dist/css/bootstrap.min.css";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import InputBase from "@mui/material/InputBase";
import { alpha, styled } from "@mui/material/styles";
import SearchIcon from "@mui/icons-material/Search";
import HomeIcon from "@mui/icons-material/Home";
import GroupIcon from "@mui/icons-material/Group";
import WorkIcon from "@mui/icons-material/Work";
import ChatIcon from "@mui/icons-material/Chat";
import NotificationsIcon from "@mui/icons-material/Notifications";
import Avatar from "@mui/material/Avatar";
import ClassRoom from '../ClassRoom';
import { Box } from '@mui/material';

const Header = () => {
    const Search = styled("div")(({ theme }) => ({
        position: "relative",
        borderRadius: theme.shape.borderRadius,
        backgroundColor: alpha(theme.palette.common.white, 0.15),
        "&:hover": {
            backgroundColor: alpha(theme.palette.common.white, 0.25),
        },
        marginLeft: 0,
        width: "100%",
        [theme.breakpoints.up("sm")]: {
            marginLeft: theme.spacing(1),
            width: "auto",
        },
    }));

    const SearchIconWrapper = styled("div")(({ theme }) => ({
        padding: theme.spacing(0, 2),
        height: "100%",
        position: "absolute",
        pointerEvents: "none",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
    }));

    const StyledInputBase = styled(InputBase)(({ theme }) => ({
        color: "inherit",
        "& .MuiInputBase-input": {
            padding: theme.spacing(1, 1, 1, 0),
            paddingLeft: `calc(1em + ${theme.spacing(4)})`,
            transition: theme.transitions.create("width"),
            width: "100%",
            [theme.breakpoints.up("md")]: {
                width: "20ch",
            },
        },
    }));
    return (


        <Box>


            <Box className=' d-lg-none d-md-none d-flex justify-content-between'>
                {/* Search Bar */}
                <IconButton className='' color="inherit">
                    <Avatar
                        alt="Profile Picture"
                        src="https://via.placeholder.com/40"
                        style={{ width: 30, height: 30 }}
                    />
                </IconButton>
                <Search>
                    <SearchIconWrapper>
                        <SearchIcon />
                    </SearchIconWrapper>
                    <StyledInputBase
                        placeholder="Search…"
                        inputProps={{ "aria-label": "search" }}
                    />
                </Search>
                <IconButton color="inherit">
                    <ChatIcon />
                </IconButton>
            </Box>



            <AppBar position="static" color="primary">



                <Toolbar className="d-flex flex-wrap justify-content-center">

                    <Search className=' d-none d-sm-block'>
                        <SearchIconWrapper>
                            <SearchIcon />
                        </SearchIconWrapper>
                        <StyledInputBase
                            placeholder="Search…"
                            inputProps={{ "aria-label": "search" }}
                        />
                    </Search>

                    {/* Navigation Links */}
                    <div className="d-flex align-items-center d-none d-sm-block">
                        <IconButton color="inherit">
                            <HomeIcon />
                            <Typography variant="body2" className="ms-2">
                                Home
                            </Typography>
                        </IconButton>

                        <IconButton color="inherit">
                            <GroupIcon />
                            <Typography variant="body2" className="ms-2">
                                Network
                            </Typography>
                        </IconButton>

                        <IconButton color="inherit">
                            <WorkIcon />
                            <Typography variant="body2" className="ms-2">
                                Jobs
                            </Typography>
                        </IconButton>

                        <IconButton color="inherit">
                            <ChatIcon />
                            <Typography variant="body2" className="ms-2">
                                Messaging
                            </Typography>
                        </IconButton>

                        <IconButton color="inherit">
                            <NotificationsIcon />
                            <Typography variant="body2" className="ms-2">
                                Notifications
                            </Typography>
                        </IconButton>

                        {/* Profile Section */}
                        <IconButton color="inherit">
                            <Avatar
                                alt="Profile Picture"
                                src="https://via.placeholder.com/40"
                                style={{ width: 30, height: 30 }}
                            />
                        </IconButton>
                    </div>
                </Toolbar>

            </AppBar>
        </Box>


    )
}

export default Header