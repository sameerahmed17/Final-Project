import React from "react";
import {
  Card,
  CardContent,
  Button,
  Grid,
  Typography,
  Container,
} from "@mui/material";

const ClassRoom = () => {
  return (
    <div className="bg-gray-100 min-h-screen flex items-center justify-center">
      <Container maxWidth="md">
        <Card className="shadow-lg rounded-2xl">
          {/* Header Section */}
          <div className="bg-blue-600 text-white p-6 rounded-t-2xl text-center">
            <Typography variant="h4" className="font-bold">
              English Communication
            </Typography>
            <Typography variant="subtitle1">Kingri C2</Typography>
          </div>

          <CardContent className="p-6">
            {/* Main Content */}
            <Grid container spacing={3}>
              {/* Left Section */}
              <Grid item xs={12} md={4}>
                <div className="bg-white shadow p-4 rounded-lg">
                  <Typography variant="h6" className="mb-4">
                    Meet
                  </Typography>
                  <Button variant="contained" color="primary" fullWidth>
                    Join
                  </Button>
                </div>

                <div className="bg-white shadow p-4 rounded-lg mt-4">
                  <Typography variant="h6" className="mb-4">
                    Upcoming
                  </Typography>
                  <Typography variant="body1">Due Friday</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Assignment 20
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    fullWidth
                    className="mt-2"
                  >
                    View all
                  </Button>
                </div>
              </Grid>

              {/* Right Section */}
              <Grid item xs={12} md={8}>
                <div className="bg-white shadow p-4 rounded-lg">
                  <Typography
                    variant="h6"
                    className="font-semibold mb-4 text-gray-700"
                  >
                    Announce something to your class
                  </Typography>
                  <div className="space-y-4">
                    {["Post 1", "Post 2", "Post 3"].map((post, index) => (
                      <div
                        key={index}
                        className="p-4 bg-gray-100 rounded-lg flex justify-between items-center"
                      >
                        <Typography>
                          {`Dummy User posted a new assignment: ${post}`}
                        </Typography>
                        <Typography
                          variant="caption"
                          color="text.secondary"
                        >
                          {index === 0 ? "Today" : `Jan ${15 + index * 5}`}
                        </Typography>
                      </div>
                    ))}
                  </div>
                </div>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Container>
    </div>
  );
};

export default ClassRoom;
